# BitBlock

Block CPU mining in your browser.

# CPU Power
Detects heavy load so that you can termnate the Tab if we have not detected the miner

# Block list
Also uses a block list of known JavaScript Miners

# Download

[![N|Solid](https://static.tagboard.com/public/img/chrome-web-store.png)](https://chrome.google.com/webstore/detail/bitblock/gbkajodabidlkclbcfdlnfoemiaejbpk)
